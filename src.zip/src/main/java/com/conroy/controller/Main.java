package com.conroy.controller;

import com.sun.xml.internal.ws.util.StringUtils;

import java.util.*;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Main {

    TreeSet<String> combinedStrSet = new TreeSet<>();

    ArrayList<String> dictionary = new ArrayList<>();
    TreeSet<String> matchedSet = new TreeSet<>();

    public static void main(String[] args) {

        ArrayList<String> dictionary = new ArrayList<>(); //record the element that needed
        dictionary.add("cat");
        dictionary.add("crater");
        dictionary.add("one");
        dictionary.add("tar");
        dictionary.add("tate");
        dictionary.add("car");
        dictionary.add("eat");
        dictionary.add("tan");
        IntStream.range(0,4).forEach(System.out::println);

        Main main = new Main(dictionary);
        List<List<Character>> grid = main.generateGrid();
//        main.getMatches(grid, 0, 0, "", new TreeMap<>());
        main.callMatchesGetter(grid);
//        System.out.println(combinedStrSet);
        main.showResult();
    }

    private void callMatchesGetter(List<List<Character>> grid){
//        IntStream.range(0, grid.size()).forEach(y->{
//            IntStream.range(0,grid.get(y).size()).forEach(x->{
//                getMatches(grid,y,x,"",new TreeMap<>());
//            });
//        });

        getMatches(grid,1,0,"",new TreeMap<>());
    }

    public Main(ArrayList<String> dictionary){
        this.dictionary = dictionary;
    }

    private List<List<Character>> generateGrid() {
        List<List<Character>> grid = new ArrayList<>();

        grid.add(Arrays.asList('C', 'A', 'T'));
        grid.add(Arrays.asList('R', 'R', 'E'));
        grid.add(Arrays.asList('Z', 'O', 'N'));

        grid.forEach(System.out::println);
        return grid;

    }


    private void getMatches(List<List<Character>> grid, int y, int x, String joinedWord, TreeMap<Integer, HashSet<Integer>> visitedCell) {
        System.out.println("x: " + x);
        if (x < 0 || y < 0)
            return;
        if (y > grid.size() - 1 || x > grid.get(y).size() -1 )
            return;
        if (!visitedCell.isEmpty() && visitedCell.containsKey(y) && visitedCell.get(y).contains(x)) {
            return;
        }
        joinedWord = (joinedWord + grid.get(y).get(x)).toLowerCase();
        combinedStrSet.add((joinedWord));

        if(dictionary.contains(joinedWord)){
            matchedSet.add(joinedWord);
        }
        ArrayList<TreeMap<Integer, HashSet<Integer>>> visitedCells = new ArrayList<>();
        IntStream.range(0,4).forEach(j->{
            TreeMap<Integer, HashSet<Integer>> currentVisitedCell = new TreeMap<>();
            currentVisitedCell.putAll(visitedCell);
            currentVisitedCell.putIfAbsent(y, new HashSet<>());
            currentVisitedCell.get(y).add(x);
            visitedCells.add(currentVisitedCell);
        });
        getMatches(grid, y - 1, x - 0, joinedWord, visitedCells.get(0));
        getMatches(grid, y - 0, x - 1, joinedWord, visitedCells.get(1));
        getMatches(grid, y + 1, x + 0, joinedWord, visitedCells.get(2));
        getMatches(grid, y + 0, x + 1, joinedWord, visitedCells.get(3));

    }

    private void showResult(){
        System.out.println(combinedStrSet);
        System.out.println(matchedSet);
    }
}
